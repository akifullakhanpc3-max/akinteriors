export const siteName = 'AkInteriors';
